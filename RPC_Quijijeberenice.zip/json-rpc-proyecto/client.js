const axios = require('axios');

async function testRPC() {
  const tests = [
    {method: 'sumar', params: [5, 3]},
    {method: 'listarUsuarios', params: []},
    {method: 'consultarClima', params: ['Madrid']},
    {method: 'sumar', params: ['a', 'b']} // Prueba de error
  ];

  for(const test of tests) {
    try {
      const response = await axios.post('http://localhost:3000/rpc', {
        jsonrpc: '2.0',
        method: test.method,
        params: test.params,
        id: Date.now()
      });
      
      console.log(`✅ ${test.method}:`, response.data.result);
    } catch (error) {
      console.error(`❌ ${test.method}:`, error.response?.data?.error || error.message);
    }
  }
}

testRPC();