const express = require('express');
const bodyParser = require('body-parser');
const jayson = require('jayson');

const app = express();
app.use(bodyParser.json());

// Crear servidor RPC
const server = new jayson.Server({
  // Método para sumar
  sumar: function(args, callback) {
    if(typeof args[0] !== 'number' || typeof args[1] !== 'number') {
      return callback(new Error('Se requieren dos números'));
    }
    callback(null, args[0] + args[1]);
  },
  
  // Método para listar usuarios
  listarUsuarios: function(args, callback) {
    const usuarios = [
      {id: 1, nombre: 'Juan Pérez'},
      {id: 2, nombre: 'María García'},
      {id: 3, nombre: 'Carlos López'}
    ];
    callback(null, usuarios);
  },
  
  // Método para consultar clima
  consultarClima: function(args, callback) {
    const climas = {
      'Madrid': 'Soleado, 25°C',
      'Barcelona': 'Parcialmente nublado, 22°C',
      'Sevilla': 'Despejado, 30°C'
    };
    callback(null, climas[args[0]] || 'No disponible');
  }
});

// Endpoint RPC
app.post('/rpc', (req, res) => {
  server.call(req.body, (err, response) => {
    if(err) {
      return res.status(500).json(err);
    }
    res.json(response);
  });
});

// Iniciar servidor
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`✅ Servidor RPC funcionando en http://localhost:${PORT}/rpc`);
});